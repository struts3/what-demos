var path = require('path')
__dirname=path.resolve('.')
console.log(__dirname)
var pre = require(__dirname+'/../../_pre/pre.js')
// -----------------------------------------------


function prePug( pug) {
	pre.prePug(__dirname, '/' + pug+'.pug', pre.onDoneFile, '/' + pug+'.html')
}

// build:
console.log('pre:')

prePug('index')
