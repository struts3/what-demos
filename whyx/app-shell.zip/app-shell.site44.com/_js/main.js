var _loaded = false

head.load(
 	'//code.jquery.com/jquery-2.2.4.min.js'
	,'/_js/libJs/jquery.smoothState.js'

	, function() {
		_loaded = true
		console.log('loaded')

		startApp()
})
// ====================================================================

function startApp() {
	//> ====================================================================
	// SS
	var ssoptions = {
		debug: true,
		onBefore: function($currentTarget, $container) {
			console.log('s:->')
		},
		onAfter: function($container, $newContent) {
			console.log('<-:e')
		}//after
	}//

	smoothState = $('#ss1').smoothState(ssoptions)
	// <====================================================================

}
