'use strict';
const express = require('express')
const middle = express()
const bodyParser = require('body-parser')
const cors = require('cors')

const homePg = require('./front_routes/homePg')
const membersPg = require('./front_routes/membersPg')

const cfenv = require('cfenv');
//set up filters chain ###################### 
middle.use(bodyParser.json()) // parse application/json
middle.use(cors())

//routes ###################### 
//middle.use('/homePg', homeFR) //front route 1 - match the front end url
middle.use('/membersPg', membersPg) //front route 1 - match the front end url

//###################### 
// get the app environment from Cloud Foundry
var appEnv = cfenv.getAppEnv();
// start server on the specified port and binding host
middle.listen(appEnv.port, '0.0.0.0', function() {
  // print a message when the server starts listening
  console.log("server starting on " + appEnv.url)
})

