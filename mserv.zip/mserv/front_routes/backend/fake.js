'use strict'

module.exports = {
_fakeBackCall: function() {
	return {
	"data": [
		[
			"Cedric Kelly",
			"Senior Javascript Developer",
			"Edinburgh",
			"6224",
			"2012/03/29",
			"$433,060"
		],
		[
			"Airi Satou",
			"Accountant",
			"Tokyo",
			"5407",
			"2008/11/28",
			"$162,700"
		],
		[
			"Rhona Davidson",
			"Integration Specialist",
			"Tokyo",
			"6200",
			"2010/10/14",
			"$327,900"
		],
		[
			"Jena Gaines",
			"Office Manager",
			"London",
			"3814",
			"2008/12/19",
			"$90,560"
		],
		[
			"Quinn Flynn",
			"Support Lead",
			"Edinburgh",
			"9497",
			"2013/03/03",
			"$342,000"
		],
		[
			"Charde Marshall",
			"Regional Director",
			"San Francisco",
			"6741",
			"2008/10/16",
			"$470,600"
		],
		[
			"Haley Kennedy",
			"Senior Marketing Designer",
			"London",
			"3597",
			"2012/12/18",
			"$313,500"
		],
		[
			"Tatyana Fitzpatrick",
			"Regional Director",
			"London",
			"1965",
			"2010/03/17",
			"$385,750"
		],
		[
			"Gloria Little",
			"Systems Administrator",
			"New York",
			"1721",
			"2009/04/10",
			"$237,500"
		],
		[
			"Bradley Greer",
			"Software Engineer",
			"London",
			"2558",
			"2012/10/13",
			"$132,000"
		],
		[
			"Doris Wilder",
			"Sales Assistant",
			"Sidney",
			"3023",
			"2010/09/20",
			"$85,600"
		],
		[
			"Angelica Ramos",
			"Chief Executive Officer (CEO)",
			"London",
			"5797",
			"2009/10/09",
			"$1,200,000"
		],
		[
			"Gavin Joyce",
			"Developer",
			"Edinburgh",
			"8822",
			"2010/12/22",
			"$92,575"
		],
		[
			"Jennifer Chang",
			"Regional Director",
			"Singapore",
			"9239",
			"2010/11/14",
			"$357,650"
		],
		[
			"Brenden Wagner",
			"Software Engineer",
			"San Francisco",
			"1314",
			"2011/06/07",
			"$206,850"
		],
		[
			"Fiona Green",
			"Chief Operating Officer (COO)",
			"San Francisco",
			"2947",
			"2010/03/11",
			"$850,000"
		],
		[
			"Suki Burks",
			"Developer",
			"London",
			"6832",
			"2009/10/22",
			"$114,500"
		],
		[
			"Prescott Bartlett",
			"Technical Author",
			"London",
			"3606",
			"2011/05/07",
			"$145,000"
		],
		[
			"Cara Stevens",
			"Sales Assistant",
			"New York",
			"3990",
			"2011/12/06",
			"$145,600"
		],
		[
			"Donna Snider",
			"Customer Support",
			"New York",
			"4226",
			"2011/01/25",
			"$112,000"
		]
	]
	}//return

}//()
} //mod
